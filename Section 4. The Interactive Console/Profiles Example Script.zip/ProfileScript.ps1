﻿## Show the student the default path to their profile
$profile

## Create a new profile
notepad $profile

## Edit the profile putting in some usual stuff and restart the console
Set-Location C:\
Set-Alias bob 'dir'
$common_directory = 'C:\Windows'